﻿namespace MC_Gym
{
    partial class frmWelcome
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmWelcome));
            this.label1 = new System.Windows.Forms.Label();
            this.btnClient = new System.Windows.Forms.Button();
            this.btnMgmt = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Maroon;
            this.label1.Font = new System.Drawing.Font("Britannic Bold", 25.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(69, 53);
            this.label1.Margin = new System.Windows.Forms.Padding(8, 0, 8, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(410, 48);
            this.label1.TabIndex = 0;
            this.label1.Text = "Welcome To MC Gym";
            // 
            // btnClient
            // 
            this.btnClient.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnClient.Font = new System.Drawing.Font("Britannic Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClient.Location = new System.Drawing.Point(88, 152);
            this.btnClient.Margin = new System.Windows.Forms.Padding(8);
            this.btnClient.Name = "btnClient";
            this.btnClient.Size = new System.Drawing.Size(301, 73);
            this.btnClient.TabIndex = 0;
            this.btnClient.Text = "Client Portal";
            this.btnClient.UseVisualStyleBackColor = false;
            this.btnClient.Click += new System.EventHandler(this.btnClient_Click);
            // 
            // btnMgmt
            // 
            this.btnMgmt.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.btnMgmt.Font = new System.Drawing.Font("Britannic Bold", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMgmt.Location = new System.Drawing.Point(88, 276);
            this.btnMgmt.Margin = new System.Windows.Forms.Padding(8);
            this.btnMgmt.Name = "btnMgmt";
            this.btnMgmt.Size = new System.Drawing.Size(301, 73);
            this.btnMgmt.TabIndex = 1;
            this.btnMgmt.Text = "Management Portal";
            this.btnMgmt.UseVisualStyleBackColor = false;
            this.btnMgmt.Click += new System.EventHandler(this.btnMgmt_Click);
            // 
            // frmWelcome
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(21F, 42F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(476, 396);
            this.Controls.Add(this.btnMgmt);
            this.Controls.Add(this.btnClient);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Arial Black", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(8);
            this.Name = "frmWelcome";
            this.Text = "Welcome to MC Gym";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnClient;
        private System.Windows.Forms.Button btnMgmt;
    }
}

