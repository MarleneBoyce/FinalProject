﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MC_Gym
{
    public partial class frmAddClient : Form
    {
        //New dbContext object called "dbContext"
        private MC_GymEntities dbContext = new MC_GymEntities();

        public frmAddClient()
        {
            InitializeComponent();
        }

        //Loading Add Client Form and setting the combo box to index 0 (--Select--)
        private void frnAddClient_Load(object sender, EventArgs e)
        {
            cmbGender.SelectedIndex = 0;
        }

        //When user hits "ADD CLIENT" the following occurs 
        private void btnAdd_Click(object sender, EventArgs e)
        {
            // Creating a new client object 
            Client client = new Client();

            //Setting the first / last name to user input
            if (txtFirstName.Text != "")
            client.FirstName = txtFirstName.Text;
            else
            {
                MessageBox.Show(this, "Please enter clients first name", "ENTER FIRST NAME",
                    MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }


            if (txtLastName.Text != "")
                client.LastName = txtLastName.Text;
            else
            {
                MessageBox.Show(this, "Please enter clients last name", "ENTER LAST NAME",
                    MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            

            //Setting combo box, if gender isn't set, a message box appears and information won't be saved 
            if (cmbGender.SelectedItem.ToString() != "--Select--")
                client.Gender = cmbGender.SelectedItem.ToString();
            else
            {
                MessageBox.Show(this, "Please select your gender", "SELECT GENDER",                        
                    MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return; 
            }

            //setting age, weight, height to user input (IF not entered, stop message box will appear and information will not be saved)
            if (txtAge.Text != "")
                client.Age = int.Parse(txtAge.Text);
            else
            {
                MessageBox.Show(this, "Please enter clients Age", "ENTER AGE",
                    MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (txtWeight.Text != "")
                client.Weight = int.Parse(txtWeight.Text);
            else
            {
                MessageBox.Show(this, "Please enter clients weight", "ENTER WEIGHT",
                    MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (txtHeight.Text != "")
                client.Height = int.Parse(txtHeight.Text);
            else
            {
                MessageBox.Show(this, "Please enter clients height", "ENTER HEIGHT",
                    MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            

            //setting phone, email to user input 
            
            if (txtPhone.Text != "")
                client.Phone = txtPhone.Text;
            else
            {
                MessageBox.Show(this, "Please enter clients phone number", "ENTER PHONE NUMBER",
                    MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }

            if (txtEmail.Text != "")
                client.Email = txtEmail.Text;
            else
            {
                MessageBox.Show(this, "Please enter clients email", "ENTER EMAIL",
                    MessageBoxButtons.OK, MessageBoxIcon.Stop);
                return;
            }
            

            //Adding the new client to the MC_GYM database 
            dbContext.Clients.Add(client);

            //Save changes executes the update statement 
            dbContext.SaveChanges();

            //Message box appears to let user know the client has been saved 
            MessageBox.Show(this, client.FirstName + " " + client.LastName + 
                            "  has been saved to our database", "CLIENT SAVED",                   
                            MessageBoxButtons.OK, MessageBoxIcon.Information);

            //Once user is saved, the form is reset
            txtFirstName.Clear();
            txtLastName.Clear();

            cmbGender.SelectedIndex = 0;

            txtAge.Clear();
            txtWeight.Clear();
            txtHeight.Clear();
            txtPhone.Clear();
            txtEmail.Clear();
        }

        //return to client portal 
        private void btnClient_Click(object sender, EventArgs e)
        {
            // return to Client Portal screen 
            this.DialogResult = DialogResult.OK;

            this.Close();
        }

        
    }
}
