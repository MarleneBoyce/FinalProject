﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MC_Gym
{
    public partial class frmCreateWorkout : Form
    {
        //This creates a new dbContext object called "dbContext"
        private MC_GymEntities dbContext = new MC_GymEntities();

        public frmCreateWorkout()
        {
            InitializeComponent();
        }
        
        //The following occurs when the "Create Workout" is loaded 
        private void frmCreateWorkout_Load(object sender, EventArgs e)
        {
            //The first line of the "Body Parts" combo box is set to empty 
            cmbBody.Items.Add(string.Empty);

            //This searches through the database using a filtered list, and finds all the body parts
            var bodyParts = from exercises in dbContext.Exercises
                            orderby exercises.BodyPart
                            select exercises.BodyPart;
            
            //To avoid duplicate entries, we only add a body part if it's not already in the combobox
            foreach (var part in bodyParts)
            {
                if (!cmbBody.Items.Contains(part))
                    cmbBody.Items.Add(part);
            }
    

            // First line of "Type" Combobox is empty 
            cmbType.Items.Add(string.Empty);

            //This searches through the database using a filtered list, and finds all the "types" of workouts 
            var types = from exercises in dbContext.Exercises
                        orderby exercises.Type
                        select exercises.Type;

            //To avoid duplicate entries, we only add a "Type" if it's not already in the combobox
            foreach (var type in types)
            {
                if (!cmbType.Items.Contains(type))
                    cmbType.Items.Add(type);
            }

            //This initializes the form inputs
            ClearData();
        }

        //When the user clicks search, the following occurs 
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //Setting the variable part and type, to what the user selected in the combobox 
            string part = cmbBody.SelectedItem.ToString();
            string type = cmbType.SelectedItem.ToString();

            //If the user doesn't select anything, nothing will happen 
            if (string.IsNullOrEmpty(part) && string.IsNullOrEmpty(type))
                return;

            //Creates a list of strings, and setting it to null 
            List<string> selection = null;

            //If the user left the "Part" empty, this will search through "Types"
            if (string.IsNullOrEmpty(part))
            {
                //This searches through the database using a filtered list, and finds all the "types" of workouts 
                var workout = from exercises in dbContext.Exercises
                              where  exercises.Type == type
                              orderby exercises.Name
                              select exercises.Name;
                
                //Selection is assigned with "Type" strings
                selection = workout.ToList();

            }
            //If the user left the "Part" empty, this will search through "Body Parts"
            else if (string.IsNullOrEmpty(type))
            {
                //This searches through the database using a filtered list, and finds all the body parts
                var workout = from exercises in dbContext.Exercises
                            where exercises.BodyPart == part
                            orderby exercises.Name
                            select exercises.Name;

                //Selection is assigned with "Body Part" strings
                selection = workout.ToList();
            }
            //If user selects both "Types" and "Body Parts"
            else
            {
                //This searches through the database using a filtered list, and finds all the "Body Parts" AND "Types"
                //that meets the criteria 
                var workout = from exercises in dbContext.Exercises
                              where exercises.BodyPart == part && exercises.Type == type
                              orderby exercises.Name
                              select exercises.Name;

                //Selection is assigned with "Body Part" AND "Types" strings
                selection = workout.ToList();
            }

            // This is to ensure that there are no duplicates exercises displayed in the Combobox Check box list 
            foreach (var exercise in selection)
            {
                if (!cblExercises.Items.Contains(exercise))
                    cblExercises.Items.Add(exercise);
            }
            
        }

        //This clears all the User Input data 
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearData();
        }

        //This occurs when the user hits "Print Workout"
        private void btnPrint_Click(object sender, EventArgs e)
        {
            //The Save Dialog box appears with the following information 
            SaveFileDialog saver = new SaveFileDialog();
            saver.InitialDirectory = "../../MC_Gyn";
            saver.Filter = "Text|*.txt";
            saver.Title = "Create A New Workout";
            saver.ShowDialog();

            //If the document has a name, then the record outputs the following 
            if (saver.FileName != "")
            {
                string record = "Your Customized Workout\n";
                record += "---------------------------------\n";

                //Outputting the exercise and a new line 
                //IF the lb box is not empty 
                if (lbWorkout.Items.Count != 0)
                {
                    foreach (var item in lbWorkout.Items)
                        record += item + Environment.NewLine;
                    
                }
                
                //Append all the text while passing through the file name and exercise records 
                File.AppendAllText(saver.FileName, record);

                //This displays a message when the file is saved
                MessageBox.Show("Please retrieve your workout at printer kiosk", "Print Workout", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        //This returns to the client portal 
        private void btnClient_Click(object sender, EventArgs e)
        {
            // return to Client Portal screen 
            this.DialogResult = DialogResult.OK;

            this.Close();
        }

        //When the user double clicks an exercise, it will transfer to the workout list box (lbWorkout) 
        private void cblExercises_SelectedIndexChanged(object sender, EventArgs e)
        {             
            lbWorkout.Items.Add(cblExercises.SelectedItem.ToString());
        }
              
        //This Clears form user input 
        private void ClearData()
        {
            cblExercises.Items.Clear();

            lbWorkout.Items.Clear();

            cmbBody.SelectedIndex = 0;

            cmbType.SelectedIndex = 0;
        }
    }
}
