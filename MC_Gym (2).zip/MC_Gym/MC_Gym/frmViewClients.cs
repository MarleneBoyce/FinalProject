﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MC_Gym
{
    public partial class frmViewClients : Form
    {
        //This creates a new dbContext object called "dbContext"
        private MC_GymEntities dbContext = new MC_GymEntities();

        public frmViewClients()
        {
            InitializeComponent();
        }

        //This occurs when the user hits "Search" 
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //first and last name are set to user input 
            string firstName = txtFirstName.Text;
            string lastName = txtLastName.Text;

            //If nothing is entered, nothing occurs 
            if (string.IsNullOrEmpty(firstName) && string.IsNullOrEmpty(lastName))
                return;
            
            //Clear box before the search 
            txtTransactions.Clear();

            //Create a list of clients and initialize to null 
            List<Client> selection = null;

            //if the last name is empty, then search through the first names 
            if (string.IsNullOrEmpty(lastName))
            {

                var clients = from c in dbContext.Clients
                              where c.FirstName == firstName
                              orderby c.LastName
                              select c;

                selection = clients.ToList();

            }
            //if the first name is empty, then search through the last names 
            else if (string.IsNullOrEmpty(firstName))
            {
                var clients = from c in dbContext.Clients
                              where c.LastName == lastName
                              orderby c.LastName
                              select c;

                selection = clients.ToList();
            }
            else
            //if both names are entered, it will search for the first and last name
            {
                var clients = from c in dbContext.Clients
                              where c.FirstName == firstName && c.LastName == lastName
                              orderby c.LastName
                              select c;

                selection = clients.ToList();
            }

            //Each time the search button is pressed, the header is outputted 
            txtTransactions.AppendText($"{"ID",-6}" + $"{"First Name",12}" +
                                        $"{"Last Name",15}" + $"{"Gender",12}" +
                                        $"{"Age",10}" + $"{"Weight",12}" +
                                        $"{"Height",12}" + $"{"Phone",17}" +
                                        $"{"Email",23}" + Environment.NewLine);

            //Here the client information is formatted 
            foreach (var client in selection)
            {
                txtTransactions.AppendText($"{client.ID.ToString(),-6}" + $"{client.FirstName,-20}" +
                                         $"{client.LastName,-15}" + $"{client.Gender,-13}" +
                                         $"{ client.Age.ToString(),-13}" + $"{client.Weight.ToString(),-15}" +
                                         $"{client.Height.ToString(),-13}" + $"{client.Phone,-15}" +
                                         $"{client.Email}" + Environment.NewLine);
            }

        }

        //If the menu button is clicked, it will return to the management portal 

        private void btnMenu_Click(object sender, EventArgs e)
        {
            // return to Management Portal screen 
            this.DialogResult = DialogResult.OK;

            this.Close();
        }


    }
}