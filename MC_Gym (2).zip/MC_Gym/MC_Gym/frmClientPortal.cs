﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MC_Gym
{
    public partial class frmClientPortal : Form
    {
        public frmClientPortal()
        {
            InitializeComponent();
        }
        //When user clicks "Add workout" the following occurs
        private void btnAddWorkout_Click(object sender, EventArgs e)
        {
            this.Hide();

            // This creates and opens the "Create Workout" form 
            Form createWorkout = new frmCreateWorkout();
            createWorkout.ShowDialog();

            this.Show();
        }

        //The occurs when the user clicks "Update Progress" 
        private void btnProgress_Click(object sender, EventArgs e)
        {
            this.Hide();

            // This creates and opens the "Update Progress" form
            Form updateProgress = new frmUpdateProgress();
            updateProgress.ShowDialog();

            this.Show();
        }
    }
}
