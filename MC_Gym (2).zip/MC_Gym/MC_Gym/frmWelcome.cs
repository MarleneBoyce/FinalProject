﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MC_Gym
{
    public partial class frmWelcome : Form
    {
        public frmWelcome()
        {
            InitializeComponent();
        }

        //If the user clicks Client portal, it will create and open the client portal form 
        private void btnClient_Click(object sender, EventArgs e)
        {
            this.Hide();
                        
            // This opens the Client Portal Form
            Form clientPortal = new frmClientPortal();
            clientPortal.ShowDialog();

            this.Show();

        }

        //If the user clicks Management portal, it will create and open the Management portal form 
        private void btnMgmt_Click(object sender, EventArgs e)
        {
            Form passwordForm = new frmPassword();
            if (passwordForm.ShowDialog() == DialogResult.OK)
            {
                this.Hide();

                // This opens the Management Portal Form
                Form mgmtPortal = new frnMgmtPortal();
                mgmtPortal.ShowDialog();
                
                this.Show();
            }
        }
    }
}
