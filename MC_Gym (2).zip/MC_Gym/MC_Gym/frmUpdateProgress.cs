﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Validation;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MC_Gym
{
    public partial class frmUpdateProgress : Form
    {
        //This creates a new dbContext object called "dbContext"
        private MC_GymEntities dbContext = new MC_GymEntities();

        public frmUpdateProgress()
        {
            InitializeComponent();
        }

        //This occurs when user hits "Search" 
        private void btnSearch_Click(object sender, EventArgs e)
        {
            //If the text box isn't empty, the following will occur 
            if (txtSearch.Text != "")
            {
                //ID is set to user input 
                int ID = int.Parse(txtSearch.Text);

                //This searches for ONE client that meets the criteria 
                var client = dbContext.Clients.First(c => c.ID == ID);

                //Setting the first, last, and current weight to the Clients information 
                txtFirstName.Text = client.FirstName;
                txtLastName.Text = client.LastName;
                txtCurWeight.Text = client.Weight.ToString();
            }
        }

        //When the user clicks "Update Progress" the following occurs 
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            //If the new weight isn't empty the following occurs 
            if (txtNewWeight.Text != "")
            {
                //Retrieiving currWeight and newWeight 
                int currWeight = int.Parse(txtCurWeight.Text);
                int newWeight = int.Parse(txtNewWeight.Text);

                //If the current weight is less than or equal to the new weight, the following message appears 
                if (currWeight <= newWeight)
                {
                    MessageBox.Show("Great job today!\nStay motivated and keep putting in the work.", "GOOD WORK", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                //If the current weight is greater than the new weight, the following message appears 
                else if (currWeight > newWeight)
                {
                    MessageBox.Show("Great job today!\n\nLooking good!\n\nStay motivated and keep putting in the work.", "VERY WELL DONE!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }

                //ID is set to user input 
                int ID = int.Parse(txtSearch.Text);

                //This searches for ONE client that meets the criteria
                var client = dbContext.Clients.First(c => c.ID == ID);

                //The clients weight is changed to the new weight 
                client.Weight = newWeight;

                //Try and catch block to ensure weight is changed 
                try
                {
                    //Save Changes sends an update query 
                    dbContext.SaveChanges();
                }
                catch (System.Data.Entity.Validation.DbEntityValidationException dbEx)
                {
                    Exception raise = dbEx;
                    foreach (var validationErrors in dbEx.EntityValidationErrors)
                    {
                        foreach (var validationError in validationErrors.ValidationErrors)
                        {
                            string message = string.Format("{0}:{1}",
                                validationErrors.Entry.Entity.ToString(),
                                validationError.ErrorMessage);
                            // raise a new exception nesting
                            // the current instance as InnerException
                            raise = new InvalidOperationException(message, raise);
                        }
                    }
                    throw raise;
                }

                //Once submitted, everything is cleared 
                txtSearch.Clear();
                txtFirstName.Clear();
                txtLastName.Clear();
                txtCurWeight.Clear();
                txtNewWeight.Clear();
            }
        }

        //This returns to the client portal 
        private void btnClient_Click(object sender, EventArgs e)
        {
           
            this.DialogResult = DialogResult.OK;

            this.Close();
        }
    }
}

