﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MC_Gym
{
    public partial class frmPassword : Form
    {       

        public frmPassword()
        {
            InitializeComponent();
        }

        //When the user clicks ok, the following occurs 
        private void btnOk_Click(object sender, EventArgs e)
        {
            //If they input the correct password, it will return DialogResult.OK and closes the form 
            //and returns to "WelcomeForm" which will then open the management portal 
            if (txtPassword.Text == "Password")
            {
                this.DialogResult = DialogResult.OK;

                this.Close();
            }
            else
            {
                //If the password is incorrect, then this message will appear 
                MessageBox.Show("You have entered the incorrect password.\nPlease enter the correct password", "INCORRECT PASSWORD", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        //When user hits cancel, then form will close and return to welcome screen 
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;

            this.Close();
        }
    }
}
