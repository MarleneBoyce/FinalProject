﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MC_Gym
{
    public partial class frnMgmtPortal : Form
    {
        public frnMgmtPortal()
        {
            InitializeComponent();
        }

        //If the user clicks add client, this will create and open the add client form 
        private void btnAddClient_Click(object sender, EventArgs e)
        {
            this.Hide();

            // This opens the Add client Form
            Form addClient = new frmAddClient();
            addClient.ShowDialog();

            this.Show();
        }

        //If the user clicks "View Client", then this will create and open the view client form
        private void btnViewClient_Click(object sender, EventArgs e)
        {
            this.Hide();

            // This opens the Client Portal Form
            Form viewClients = new frmViewClients();
            viewClients.ShowDialog();

            this.Show();
        }
    }
}
